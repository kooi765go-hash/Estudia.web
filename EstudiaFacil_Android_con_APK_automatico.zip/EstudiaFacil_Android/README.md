# EstudiaFácil — App Android v1

Esta es la primera versión Android de EstudiaFácil.

Incluye la página actual dentro de una app Android para que funcione sin conexión:
- Calculadora de notas
- Quiz rápido
- Temporizador de estudio
- Consejos de estudio
- Materias
- Sección Premium preparada para futuras funciones

## Cómo abrirla
1. Abre el proyecto en Android Studio.
2. Espera a que Gradle sincronice.
3. Pulsa Run para probarla en un teléfono o emulador.
4. Para Google Play, habrá que preparar el lanzamiento, icono, ficha de la app,
   política de privacidad y los requisitos de la cuenta de desarrollador.

Nota: este archivo es el proyecto fuente; no es todavía un APK firmado para publicar.
